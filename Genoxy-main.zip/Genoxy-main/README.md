# Genarcy V-5

This is First Created by Golden [Rammerhq] 
Genarcy has permission by me to use the templete-
templete is forked by [Rammerhqalt] in order to give access-

# Your Permissions- 
you may not edit the code- you can fork and deploy to render
you may not use the games without asking Genarcy or Golden on the Genarcy discord


# Collaberators
[Rammehq] or [RammerhqAlt] and [Genarcy]

