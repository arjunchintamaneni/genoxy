# Security Policy

## Supported Versions
Genarcy Revamp-5.0



## Reporting a Vulnerability

Go to The genarcy discord

